from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from config import TELEGRAM_BOT_TOKEN
from scheduler import start_scheduler, CHAT_ID
from analysis import get_gold_analysis

# This will allow the scheduler to update the global CHAT_ID
import scheduler

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    scheduler.CHAT_ID = update.effective_chat.id
    await update.message.reply_text("📡 Forex Gold Bot activated! You will receive signals every 15 minutes.")

async def gold(update: Update, context: ContextTypes.DEFAULT_TYPE):
    analysis = get_gold_analysis()
    await update.message.reply_text(analysis)

app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("gold", gold))

start_scheduler()
app.run_polling()
