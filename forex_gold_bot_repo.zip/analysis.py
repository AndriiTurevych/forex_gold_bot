import yfinance as yf
import pandas as pd

def get_gold_analysis():
    df = yf.download('XAUUSD=X', period='2d', interval='15m')
    if df.empty:
        return "❌ Could not retrieve data."

    df['RSI'] = compute_rsi(df['Close'])
    df['EMA12'] = df['Close'].ewm(span=12).mean()
    df['EMA26'] = df['Close'].ewm(span=26).mean()
    df['MACD'] = df['EMA12'] - df['EMA26']

    latest = df.iloc[-1]
    rsi = latest['RSI']
    macd = latest['MACD']
    close = latest['Close']

    signal = ""
    if rsi > 70 and macd < 0:
        signal = "SELL"
    elif rsi < 30 and macd > 0:
        signal = "BUY"
    else:
        signal = "NEUTRAL"

    return f"""
📊 Gold (XAU/USD) Signal - 15m Chart
Price: {close:.2f} USD
RSI: {rsi:.2f}
MACD: {macd:.2f}

🔔 Signal: {signal}
"""

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))
