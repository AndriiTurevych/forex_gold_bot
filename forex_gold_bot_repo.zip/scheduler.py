from apscheduler.schedulers.background import BackgroundScheduler
from analysis import get_gold_analysis
from telegram import Bot
from config import TELEGRAM_BOT_TOKEN

bot = Bot(token=TELEGRAM_BOT_TOKEN)

CHAT_ID = None  # Will be set when user sends /start

def job():
    if CHAT_ID:
        text = get_gold_analysis()
        bot.send_message(chat_id=CHAT_ID, text=text)

def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(job, 'interval', minutes=15)
    scheduler.start()
